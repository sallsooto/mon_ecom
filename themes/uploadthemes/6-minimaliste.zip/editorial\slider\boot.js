	$(function() {
	
		$( "#slides" ).accessNews({
	        headline : "Categories",
	        speed : "normal",
			slideBy : 1
	    });
		
		
	});