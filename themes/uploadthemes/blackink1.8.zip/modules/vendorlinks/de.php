<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{vendorlinks}prestashop>vendorlinks_f26711692ce59ea0782fb28474e99dee'] = 'Hersteller Block';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_9859921e6d3733788e09599adb681dcd'] = 'Zeigt einen Block von Hersteller / Marken';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_cf64d2d0bc5de5ce3d309d0e899d36fb'] = 'Ungültige Anzahl von Elementen';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_bb30aac3161f999a357af767ce2fd7ec'] = 'Bitte aktivieren Sie mindestens ein System Liste';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_c888438d14855d7d96a2724ee9c306bd'] = 'Bitte activSettings aktualisiert';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_bfdff752293014f11f17122c92909ad5'] = 'Verwenden Sie ein Klartext-Liste';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'aktiviert';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_b9f5c797ebbf55adccdd8539a65a0241'] = 'Behinderte';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'Anzeige';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_6a7f245843454cf4f28ad7c5e2572aa2'] = 'Elemente';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_2e5acd674f7f821a81e99ed01d5305d1'] = 'Um Herstellern in einer Nur-Text-Liste angezeigt';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_b0fa976774d2acf72f9c62e9ab73de38'] = 'Verwenden Sie eine Dropdown-Liste';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_f68d82d608d94a571e0984a0288595e0'] = 'Um Herstellern in einem Dropdown-Liste Display';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_c9cc8cce247e49bae79f15173ce97354'] = 'Sparen';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_2377be3c2ad9b435ba277a73f0f1ca76'] = 'Hersteller';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_49fa2426b7903b3d4c89e2c1874d9346'] = 'mehr über';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_1c407c118b89fa6feaae6b0af5fc0970'] = 'Kein Hersteller';
