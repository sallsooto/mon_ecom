<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{vendorlinks}prestashop>vendorlinks_f26711692ce59ea0782fb28474e99dee'] = 'proveedor de bloques';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_9859921e6d3733788e09599adb681dcd'] = 'Muestra un bloque de fabricantes / marcas';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_cf64d2d0bc5de5ce3d309d0e899d36fb'] = 'No válido número de elementos';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_bb30aac3161f999a357af767ce2fd7ec'] = 'Por favor, active por lo menos un sistema de listas';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_c888438d14855d7d96a2724ee9c306bd'] = 'Did you mean: Settings update configuración actualizada';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_f4f70727dc34561dfde1a3c529b6205c'] = 'configuración';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_bfdff752293014f11f17122c92909ad5'] = 'Utilice una lista de texto';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'activado';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_b9f5c797ebbf55adccdd8539a65a0241'] = 'discapacitado';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_b9987a246a537f4fe86f1f2e3d10dbdb'] = 'mostrar';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_6a7f245843454cf4f28ad7c5e2572aa2'] = 'Delements';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_2e5acd674f7f821a81e99ed01d5305d1'] = 'Para visualizar los fabricantes en una lista de texto';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_b0fa976774d2acf72f9c62e9ab73de38'] = 'Utilice una lista desplegable';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_f68d82d608d94a571e0984a0288595e0'] = 'Para visualizar los fabricantes en una lista desplegable';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_c9cc8cce247e49bae79f15173ce97354'] = 'ahorrar';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_2377be3c2ad9b435ba277a73f0f1ca76'] = 'fabricantes';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_49fa2426b7903b3d4c89e2c1874d9346'] = 'más información acerca de';
$_MODULE['<{vendorlinks}prestashop>vendorlinks_1c407c118b89fa6feaae6b0af5fc0970'] = 'ningún otro fabricante de';
