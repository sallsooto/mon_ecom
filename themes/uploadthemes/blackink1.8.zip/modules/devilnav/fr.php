<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{devilnav}prestashop>devilnav_9314f391f209ae4aa0a242f1e29a4b78'] = 'diable de navigation';
$_MODULE['<{devilnav}prestashop>devilnav_b920b96ed6ec4197045552bfe981da17'] = 'Pour afficher l\'en-tête de navigation';
$_MODULE['<{devilnav}prestashop>devilnav_23e0d4ecc25de9b2777fdaca3e2f3193'] = 'Profondeur maximale: numéro non valide.';
$_MODULE['<{devilnav}prestashop>devilnav_0cf328636f0d607ac24a5c435866b94b'] = 'Dynamic HTML: choix valide.';
$_MODULE['<{devilnav}prestashop>devilnav_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'confirmation';
$_MODULE['<{devilnav}prestashop>devilnav_c888438d14855d7d96a2724ee9c306bd'] = 'paramètres mis à jour';
$_MODULE['<{devilnav}prestashop>devilnav_f4f70727dc34561dfde1a3c529b6205c'] = 'réglages';
$_MODULE['<{devilnav}prestashop>devilnav_19561e33450d1d3dfe6af08df5710dd0'] = 'La profondeur maximale';
$_MODULE['<{devilnav}prestashop>devilnav_ef35cd8f1058f29151991e9ca94b36fb'] = 'Réglez la profondeur maximale de sous-niveaux affichés dans ce bloc (0 = infini)';
$_MODULE['<{devilnav}prestashop>devilnav_971fd8cc345d8bd9f92e9f7d88fdf20c'] = 'dynamique';
$_MODULE['<{devilnav}prestashop>devilnav_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{devilnav}prestashop>devilnav_b9f5c797ebbf55adccdd8539a65a0241'] = 'réduite';
$_MODULE['<{devilnav}prestashop>devilnav_2c1199ee18b344152f35ec237acb5796'] = 'Activer dynamique (animation) mode de sous-niveaux';
$_MODULE['<{devilnav}prestashop>devilnav_4f32360218e145e3ba681a2343015eb3'] = 'Pied de plusieurs colonnes';
$_MODULE['<{devilnav}prestashop>devilnav_3d81ca758785a8528208613752ad2c81'] = 'Définissez le nombre de colonnes footer';
$_MODULE['<{devilnav}prestashop>devilnav_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{devilnav}prestashop>devilnav_af1b98adf7f686b84cd0b443e022b7a0'] = 'catégories';
$_MODULE['<{devilnav}prestashop>devilnav_footer_af1b98adf7f686b84cd0b443e022b7a0'] = 'catégories';
