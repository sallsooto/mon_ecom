$(document).ready(function(){
$("table#cart_summary").draggable({ axis: "x" });
				
					
	$('.informations_block_left ul li:last-child').addClass('last');
	$('#viewed-products_block_left ul li:nth-child(odd)').addClass('odd');
	$('#viewed-products_block_left ul li:nth-child(even)').addClass('even');
	$('#new-products_block_right ul li:nth-child(odd)').addClass('odd');
	$('#new-products_block_right ul li:nth-child(even)').addClass('even');
   $('input[type=text]').addClass('inputBox');
   $('input[type=password]').addClass('inputBox');
	$('table tbody tr:nth-child(odd)').addClass('odd');
	$('table tbody tr:nth-child(even)').addClass('even');
	$('table#cart_summary tfoot tr td:first-child').addClass('first-child');
	$('table#cart_summary tfoot tr td:flast-child').addClass('last-child');
	$('input[type=text],input[type=password]').addClass('txtBox');
	$('ul#header_links li:first-child').addClass('first-child');
	$('ul li a img').each(function(){
		$(this).parent().addClass('imgLink');
	})
	$('ul li:nth-child(odd)').addClass('odd');
	$('ul li:nth-child(even)').addClass('even');
	var config =false;
	var logoheight=$('a#header_logo img').height()+"px";
	$('.config').css('height',logoheight)
	$('.config').click(function(){
		if(config==false){
		$('#header #currencies_block_top').css('display','block');
		$('div#languages_block_top').css('display','block')
		config=true;
		}else{
		$('#header #currencies_block_top').css('display','none');
		$('div#languages_block_top').css('display','none')
		config=false;
		}
	})
	
	
		
	
})

