<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpermanentlinks}blackink>blockpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contacter';
$_MODULE['<{blockpermanentlinks}blackink>blockpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'plan du site';
$_MODULE['<{blockpermanentlinks}blackink>blockpermanentlinks-header_fad9383ed4698856ed467fd49ecf4820'] = 'bookmark';
