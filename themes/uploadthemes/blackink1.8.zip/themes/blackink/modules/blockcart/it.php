<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcart}prestashop>blockcart_20351b3328c35ab617549920f5cb4939'] = 'Personalizzazione n.';
$_MODULE['<{blockcart}prestashop>blockcart_ed6e9a09a111035684bb23682561e12d'] = 'rimuovi questo prodotto dal mio carrello';
$_MODULE['<{blockcart}prestashop>blockcart_a85eba4c6c699122b2bb1387ea4813ad'] = 'Carrello';
$_MODULE['<{blockcart}prestashop>blockcart_86024cad1e83101d97359d7351051156'] = 'prodotti';
$_MODULE['<{blockcart}prestashop>blockcart_f5bf48aa40cad7891eb709fcf1fde128'] = 'prodotto';
$_MODULE['<{blockcart}prestashop>blockcart_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(vuoto)';
$_MODULE['<{blockcart}prestashop>blockcart_4b7d496eedb665d0b5f589f2f874e7cb'] = 'Dettaglio prodotto';
$_MODULE['<{blockcart}prestashop>blockcart_853ae90f0351324bd73ea615e6487517'] = ':';
$_MODULE['<{blockcart}prestashop>blockcart_09dc02ecbb078868a3a86dded030076d'] = 'Nessun prodotto';
$_MODULE['<{blockcart}prestashop>blockcart_f2a6c498fb90ee345d997f888fce3b18'] = 'Elimina';
$_MODULE['<{blockcart}prestashop>blockcart_ea9cf7e47ff33b2be14e6dd07cbcefc6'] = 'Spedizione';
$_MODULE['<{blockcart}prestashop>blockcart_ba794350deb07c0c96fe73bd12239059'] = 'Imballaggio';
$_MODULE['<{blockcart}prestashop>blockcart_4b78ac8eb158840e9638a3aeb26c4a9d'] = 'Tasse';
$_MODULE['<{blockcart}prestashop>blockcart_96b0141273eabab320119c467cdcaf17'] = 'Totale';
$_MODULE['<{blockcart}prestashop>blockcart_0d11c2b75cf03522c8d97938490466b2'] = 'I prezzi sono IVA inclusa';
$_MODULE['<{blockcart}prestashop>blockcart_41202aa6b8cf7ae885644717dab1e8b4'] = 'I prezzi sono IVA esclusa';
$_MODULE['<{blockcart}prestashop>blockcart_377e99e7404b414341a9621f7fb3f906'] = 'Check out';
$_MODULE['<{blockcart}prestashop>blockcart_c2e1362a9710a3dd86f937c2ea1f336d'] = 'Blocco carrello';
$_MODULE['<{blockcart}prestashop>blockcart_e03093a5753b436ee1de63b6e3e1bd02'] = 'Aggiunge un blocco contenente il carrello del cliente';
$_MODULE['<{blockcart}prestashop>blockcart_eb4ae207521bbe6403f7fe9564d38cda'] = 'Ajax: scelta non valida.';
$_MODULE['<{blockcart}prestashop>blockcart_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Conferma';
$_MODULE['<{blockcart}prestashop>blockcart_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornate';
$_MODULE['<{blockcart}prestashop>blockcart_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockcart}prestashop>blockcart_614a8820aa4ac08ce2ee398a41b10778'] = 'Carrello Ajax ';
$_MODULE['<{blockcart}prestashop>blockcart_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{blockcart}prestashop>blockcart_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disattivato';
$_MODULE['<{blockcart}prestashop>blockcart_dba281afb9a38e654ea9dab4cd6cb0ca'] = 'Attivare la modalità di AJAX per il carrello (compatibile con il tema di default)';
$_MODULE['<{blockcart}prestashop>blockcart_c9cc8cce247e49bae79f15173ce97354'] = 'Salva';

?>