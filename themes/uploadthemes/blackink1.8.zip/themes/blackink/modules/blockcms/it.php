<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcms}blackink>blockcms_34c869c542dee932ef8cd96d2f91cae6'] = 'I nostri negozi';
$_MODULE['<{blockcms}blackink>blockcms_d1aa22a3126f04664e0fe3f598994014'] = 'Specials';
$_MODULE['<{blockcms}blackink>blockcms_9ff0635f5737513b1a6f559ac2bff745'] = 'nuovi prodotti';
$_MODULE['<{blockcms}blackink>blockcms_3cb29f0ccc5fd220a97df89dafe46290'] = 'I più venduti';
$_MODULE['<{blockcms}blackink>blockcms_02d4482d332e1aef3437cd61c9bcc624'] = 'Contattaci';
