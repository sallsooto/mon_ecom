<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcms}blackink>blockcms_34c869c542dee932ef8cd96d2f91cae6'] = 'Nos Magasins';
$_MODULE['<{blockcms}blackink>blockcms_d1aa22a3126f04664e0fe3f598994014'] = 'Promotions';
$_MODULE['<{blockcms}blackink>blockcms_9ff0635f5737513b1a6f559ac2bff745'] = 'Nouveaux produits';
$_MODULE['<{blockcms}blackink>blockcms_3cb29f0ccc5fd220a97df89dafe46290'] = 'Meilleures ventes';
$_MODULE['<{blockcms}blackink>blockcms_02d4482d332e1aef3437cd61c9bcc624'] = 'Contactez-nous';
