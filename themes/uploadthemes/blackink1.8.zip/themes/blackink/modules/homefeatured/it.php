<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{homefeatured}blackink>homefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Prodotti in Vetrina';
$_MODULE['<{homefeatured}blackink>homefeatured_d3da97e2d9aee5c8fbe03156ad051c99'] = 'di più';
$_MODULE['<{homefeatured}blackink>homefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'vista';
$_MODULE['<{homefeatured}blackink>homefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'Aggiungi al carrello';
$_MODULE['<{homefeatured}blackink>homefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Non ci sono prodotti in vetrina';
