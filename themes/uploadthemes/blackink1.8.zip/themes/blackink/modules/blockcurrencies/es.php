<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcurrencies}blackink>blockcurrencies_386c339d37e737a436499d423a77df0c'] = 'Moneda';
